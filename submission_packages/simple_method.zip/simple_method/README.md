# Simple method: random-network flow

Sparse Kirchhoff solver, uncertainty analysis and grouped Sobol sensitivity.

Read reports/report_en.pdf and reports/presentation_en.pdf first. Verification evidence is in reports/verification/verification_slides.pdf. Complete saved results and run settings are in results/.

Python 3.12 was used. From this folder:

```bash
python -m pip install -r requirements.txt
python -m pip install -e .
python -m pytest -q
python scripts/demo.py --n 25 --p .6 --sigma 1 --seed 42
OPENBLAS_NUM_THREADS=1 python scripts/run_study.py
python scripts/make_figures.py
```

Saved results are already computed; rerunning is optional. Variables are dimensionless. The regular 2D lattice uses exploratory distributions and has not been calibrated to geological field data.
