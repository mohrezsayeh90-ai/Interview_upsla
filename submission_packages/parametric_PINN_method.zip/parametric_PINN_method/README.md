# Parametric graph PINN method

Physics-informed unrolled graph model with trained weights and a matched comparison to the sparse reference solver.

Read parametric_pinn/reports/comparison_en.pdf and comparison_slides.pdf first. The checkpoint is parametric_pinn/models/parametric_pinn.pt. Training, accuracy, sensitivity and timing results are under parametric_pinn/results/.

Python 3.12 and CPU PyTorch were used. From this folder:

```bash
python -m pip install -r requirements.txt
python -m pip install -e .
python parametric_pinn/scripts/predict.py --p .6 --sigma 1 --seed 42
python parametric_pinn/scripts/predict.py --delta .25 --sigma 1 --draws 1000
python -m pytest -q tests parametric_pinn/tests
```

Prediction uses saved weights without a sparse reference solve. The full conductance field or a seed identifying it is required; distribution parameters alone do not identify a realization. Each input still receives graph preprocessing and fixed iterative head updates. Effective conductance is estimated from energy; boundary-flux and local-conservation errors are reported separately. The model was slower than the direct solver on the small CPU benchmark. Outliers and the unmet validation target are retained in the report.

Optional reproduction:

```bash
OPENBLAS_NUM_THREADS=1 python parametric_pinn/scripts/train.py
OPENBLAS_NUM_THREADS=1 python parametric_pinn/scripts/evaluate.py
```

Training uses no solution labels. Reference solutions are used for validation and evaluation. The reference code is included as a dependency.
